﻿namespace CWProject
{
    public class SPhonesTablets : StoreObject
    {
        public string SerialNum { set; get; }
        public int DisplaySize { set; get; }
        public int OperMemory { set; get; }
        public int HardMemory { set; get; }
        public string OperSystem { set; get; }
        public string Type { set; get; }
    }
}
