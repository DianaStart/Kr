﻿using System;
using System.Windows;

namespace CWProject
{
    /// <summary>
    /// Логика взаимодействия для AddUpdateSW.xaml
    /// </summary>
    public partial class AddUpdateSW : Window
    {
        MainWindow mw;
        bool isChange;
        public AddUpdateSW()
        {
            InitializeComponent();
            this.mw = null;
            isChange = false;
        }

        public AddUpdateSW(MainWindow mw)
        {
            InitializeComponent();
            this.mw = mw;
            isChange = false;
        }

        public AddUpdateSW(MainWindow mw, SmartWatches sw)
        {
            InitializeComponent();
            this.mw = mw;
            isChange = true;
            tbID.Text = sw.ID.ToString();
            tbName.Text = sw.Name;
            tbBarCode.Text = sw.BarCode;
            tbWorkTime.Text = sw.WorkTime.ToString();
            tbStepCount.Text = sw.StepCount;
            tbPulseCount.Text = sw.PulseCount;
            tbAlarmClock.Text = sw.Alarm;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            this.Close();
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if (!isChange)
            {
                SmartWatches sw = new SmartWatches
                {
                    ID = 0,
                    Name = tbName.Text,
                    BarCode = tbBarCode.Text,
                    WorkTime = Convert.ToInt32(tbWorkTime.Text),
                    StepCount = tbStepCount.Text,
                    PulseCount = tbPulseCount.Text,
                    Alarm = tbAlarmClock.Text
                };
                mw.AddDataToTable("SmartWatches", sw);
            }
            else
            {
                SmartWatches sw = new SmartWatches
                {
                    ID = Convert.ToInt32(tbID.Text),
                    Name = tbName.Text,
                    BarCode = tbBarCode.Text,
                    WorkTime = Convert.ToInt32(tbWorkTime.Text),
                    StepCount = tbStepCount.Text,
                    PulseCount = tbPulseCount.Text,
                    Alarm = tbAlarmClock.Text
                };
                mw.UpdateDataInTable("SmartWatches", sw);
            }
            DialogResult = true;
            this.Close();
        }
    }
}
