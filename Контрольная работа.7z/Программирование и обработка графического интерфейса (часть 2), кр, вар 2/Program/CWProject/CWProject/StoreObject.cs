﻿namespace CWProject
{
    public class StoreObject
    {
        public int ID { set; get; }
        public string Name { set; get; }
        public string BarCode { set; get; }
    }
}
