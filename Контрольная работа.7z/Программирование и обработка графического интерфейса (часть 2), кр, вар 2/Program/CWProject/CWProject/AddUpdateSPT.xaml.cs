﻿using System;
using System.Windows;

namespace CWProject
{
    /// <summary>
    /// Логика взаимодействия для AddUpdateSPT.xaml
    /// </summary>
    public partial class AddUpdateSPT : Window
    {
        MainWindow mw;
        bool isChange;
        public AddUpdateSPT()
        {
            InitializeComponent();
            mw = null;
            isChange = false;
        }

        public AddUpdateSPT(MainWindow mw)
        {
            InitializeComponent();
            this.mw = mw;
            isChange = false;
        }

        public AddUpdateSPT(MainWindow mw, SPhonesTablets spt)
        {
            InitializeComponent();
            this.mw = mw;
            isChange = true;
            tbID.Text = spt.ID.ToString();
            tbName.Text = spt.Name;
            tbBarCode.Text = spt.BarCode;
            tbSerialNum.Text = spt.SerialNum;
            tbDisplaySize.Text = spt.DisplaySize.ToString();
            tbOperMem.Text = spt.OperMemory.ToString();
            tbHardMem.Text = spt.HardMemory.ToString();
            tbOperSys.Text = spt.OperSystem;
            tbType.Text = spt.Type;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            this.Close();
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            if (!isChange)
            {
                SPhonesTablets spt = new SPhonesTablets
                {
                    ID = 0,
                    Name = tbName.Text,
                    BarCode = tbBarCode.Text,
                    SerialNum = tbSerialNum.Text,
                    DisplaySize = Convert.ToInt32(tbDisplaySize.Text),
                    OperMemory = Convert.ToInt32(tbOperMem.Text),
                    HardMemory = Convert.ToInt32(tbHardMem.Text),
                    OperSystem = tbOperSys.Text,
                    Type = tbType.Text
                };
                mw.AddDataToTable("SPhonesTablets", spt);
            }
            else
            {
                SPhonesTablets sw = new SPhonesTablets
                {
                    ID = Convert.ToInt32(tbID.Text),
                    Name = tbName.Text,
                    BarCode = tbBarCode.Text,
                    DisplaySize = Convert.ToInt32(tbDisplaySize.Text),
                    OperMemory = Convert.ToInt32(tbOperMem.Text),
                    HardMemory = Convert.ToInt32(tbHardMem.Text),
                    OperSystem = tbOperSys.Text,
                    Type = tbType.Text
                };
                mw.UpdateDataInTable("SPhonesTablets", sw);
            }
            DialogResult = true;
            this.Close();
        }
    }
}
