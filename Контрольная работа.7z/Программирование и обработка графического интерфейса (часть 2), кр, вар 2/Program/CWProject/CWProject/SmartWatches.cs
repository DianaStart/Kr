﻿namespace CWProject
{
    public class SmartWatches : StoreObject
    {
        public int WorkTime { set; get; }
        public string StepCount { set; get; }
        public string PulseCount { set; get; }
        public string Alarm { set; get; }

    }
}
