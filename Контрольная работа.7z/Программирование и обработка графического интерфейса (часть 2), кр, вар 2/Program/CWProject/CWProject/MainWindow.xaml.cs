﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Data.SQLite;


namespace CWProject
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string dbName = "Database.db";
        public SQLiteConnection conn;

        public MainWindow()
        {
            InitializeComponent();
            connectDB();
            ListBoxItem item = (ListBoxItem)cbDataObjects.SelectedItem;
            string table = item.Content.ToString();
            updateGridDataItems(table);
        }

        public void connectDB()
        {
            conn = new SQLiteConnection("Data Source=" + dbName);
            conn.Open();
        }

        public List<StoreObject> GetDataFromTable(string tableName)
        {
            connectDB();
            List<StoreObject> list = new List<StoreObject>();
            SQLiteCommand command = conn.CreateCommand();
            command.CommandText = "SELECT * FROM " + tableName;
            SQLiteDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                if (tableName == "SmartWatches")
                {
                    SmartWatches sw = new SmartWatches
                    {
                        ID = Convert.ToInt32(reader["ID"].ToString()),
                        Name = reader["Name"].ToString(),
                        BarCode = reader["BarCode"].ToString(),
                        WorkTime = Convert.ToInt32(reader["WorkTime"].ToString()),
                        StepCount = reader["StepCount"].ToString(),
                        PulseCount = reader["PulseCount"].ToString(),
                        Alarm = reader["Alarm"].ToString()
                    };
                    list.Add(sw);
                }
                else if (tableName == "SPhonesTablets")
                {
                    SPhonesTablets spt = new SPhonesTablets
                    {
                        ID = Convert.ToInt32(reader["ID"].ToString()),
                        Name = reader["Name"].ToString(),
                        BarCode = reader["BarCode"].ToString(),
                        SerialNum = reader["SerialNum"].ToString(),
                        DisplaySize = Convert.ToInt32(reader["DisplaySize"].ToString()),
                        OperMemory = Convert.ToInt32(reader["OperMemory"].ToString()),
                        HardMemory = Convert.ToInt32(reader["HardMemory"].ToString()),
                        OperSystem = reader["OperSystem"].ToString(),
                        Type = reader["Type"].ToString()
                    };
                    list.Add(spt);
                }
            }
            reader.Close();
            conn.Close();
            if (list.Count > 0)
                return list;
            else
                return null;
        }

        public void AddDataToTable(string table, StoreObject so)
        {
            if (so == null)
                return;
            connectDB();
            if (table == "SmartWatches")
            {
                SmartWatches sw = (SmartWatches)so;
                string query = @"INSERT INTO SmartWatches (Name, Barcode, WorkTime, StepCount, PulseCount, Alarm) VALUES (@Name, @Barcode, @WorkTime, @StepCount, @PulseCount, @Alarm)";
                SQLiteCommand command = new SQLiteCommand(query, conn);
                command.Parameters.AddWithValue("@Name", sw.Name);
                command.Parameters.AddWithValue("@BarCode", sw.BarCode);
                command.Parameters.AddWithValue("@WorkTime", sw.WorkTime);
                command.Parameters.AddWithValue("@StepCount", sw.StepCount);
                command.Parameters.AddWithValue("@PulseCount", sw.PulseCount);
                command.Parameters.AddWithValue("@Alarm", sw.Alarm);
                command.ExecuteNonQuery();
            }
            else if (table == "SPhonesTablets")
            {
                SPhonesTablets spt = (SPhonesTablets)so;
                string query = @"INSERT INTO SPhonesTablets (Name, Barcode, SerialNum, DisplaySize, OperMemory, HardMemory, OperSystem, Type) VALUES (@Name, @Barcode, @SerialNum, @DisplaySize, @OperMemory, @HardMemory, @OperSystem, @Type)";
                SQLiteCommand command = new SQLiteCommand(query, conn);
                command.Parameters.AddWithValue("@Name", spt.Name);
                command.Parameters.AddWithValue("@Barcode", spt.BarCode);
                command.Parameters.AddWithValue("@SerialNum", spt.SerialNum);
                command.Parameters.AddWithValue("@DisplaySize", spt.DisplaySize);
                command.Parameters.AddWithValue("@OperMemory", spt.OperMemory);
                command.Parameters.AddWithValue("@HardMemory", spt.HardMemory);
                command.Parameters.AddWithValue("@OperSystem", spt.OperSystem);
                command.Parameters.AddWithValue("@Type", spt.Type);
                command.ExecuteNonQuery();
            }
            conn.Close();
        }       

        void setDataGridHeaders(string type)
        {
            gdvDataBase.Columns.Clear();
            if (type == "SmartWatches")
            {
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "ID", Binding = new Binding("ID") });
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "Name", Binding = new Binding("Name") });
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "Barcode", Binding = new Binding("BarCode") });
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "Work Time", Binding = new Binding("WorkTime") });
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "Step Counter", Binding = new Binding("StepCount") });
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "Pulse Counter", Binding = new Binding("PulseCount") });
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "Alarm Clock", Binding = new Binding("Alarm") });
            }
            else if (type == "SPhonesTablets")
            {
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "ID", Binding = new Binding("ID") });
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "Name", Binding = new Binding("Name") });
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "Barcode", Binding = new Binding("BarCode") });
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "Serial Number", Binding = new Binding("SerialNum") });
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "Oper Memory", Binding = new Binding("OperMemory") });
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "Hard Memory", Binding = new Binding("HardMemory") });
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "Operation System", Binding = new Binding("OperSystem") });
                gdvDataBase.Columns.Add(new DataGridTextColumn { Header = "Device Type", Binding = new Binding("Type") });
            }
        }

        public void UpdateDataInTable(string table, StoreObject so)
        {
            if (so == null)
                return;
            connectDB();
            if (table == "SmartWatches")
            {
                SmartWatches sw = (SmartWatches)so;
                string query = @"UPDATE SmartWatches SET Name = @Name, BarCode = @BarCode, WorkTime = @WorkTime, StepCount = @StepCount, PulseCount = @PulseCount, Alarm = @Alarm WHERE ID = @ID";
                SQLiteCommand command = new SQLiteCommand(query, conn);
                command.Parameters.AddWithValue("@ID", sw.ID);
                command.Parameters.AddWithValue("@Name", sw.Name);
                command.Parameters.AddWithValue("@BarCode", sw.BarCode);
                command.Parameters.AddWithValue("@WorkTime", sw.WorkTime);
                command.Parameters.AddWithValue("@StepCount", sw.StepCount);
                command.Parameters.AddWithValue("@PulseCount", sw.PulseCount);
                command.Parameters.AddWithValue("@Alarm", sw.Alarm);
                command.ExecuteNonQuery();
            }
            else if (table == "SPhonesTablets")
            {
                SPhonesTablets spt = (SPhonesTablets)so;
                string query = @"UPDATE SPhonesTablets SET Name = @Name, BarCode = @BarCode, SerialNum = @SerialNum, OperMemory = @OperMemory, HardMemory = @HardMemory, OperSystem = @OperSystem, Type = @Type WHERE ID = @ID";
                SQLiteCommand command = new SQLiteCommand(query, conn);
                command.Parameters.AddWithValue("@ID", spt.ID);
                command.Parameters.AddWithValue("@Name", spt.Name);
                command.Parameters.AddWithValue("@BarCode", spt.BarCode);
                command.Parameters.AddWithValue("@SerialNum", spt.SerialNum);
                command.Parameters.AddWithValue("@OperMemory", spt.OperMemory);
                command.Parameters.AddWithValue("@HardMemory", spt.HardMemory);
                command.Parameters.AddWithValue("@OperSystem", spt.OperSystem);
                command.Parameters.AddWithValue("@Type", spt.Type);
                command.ExecuteNonQuery();
            }
            conn.Close();
        }

        public void DeleteDataFromTable(string table, int id)
        {
            connectDB();
            if (table == "SmartWatches")
            {
                string query = "DELETE FROM SmartWatches WHERE ID = @ID";
                SQLiteCommand comm = new SQLiteCommand(query, conn);
                comm.Parameters.AddWithValue("@ID", id);
                comm.ExecuteNonQuery();
            }
            else if (table == "SPhonesTablets")
            {
                string query = "DELETE FROM SPhonesTablets WHERE ID = @ID";
                SQLiteCommand comm = new SQLiteCommand(query, conn);
                comm.Parameters.AddWithValue("@ID", id);
                comm.ExecuteNonQuery();
            }
            conn.Close();
        }

        private void cbDataObjects_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListBoxItem item = (ListBoxItem)cbDataObjects.SelectedItem;
            string table = item.Content.ToString();
            updateGridDataItems(table);
        }

        public void updateGridDataItems(string tType)
        {
            if (gdvDataBase == null)
                return;
            gdvDataBase.Columns.Clear();
            gdvDataBase.Items.Clear();
            string dType = tType;
            List<StoreObject> data = GetDataFromTable(dType);
            setDataGridHeaders(dType);
            foreach (var item in data)
            {
                gdvDataBase.Items.Add(item);
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            string table = cbDataObjects.Text;
            if (table == "SmartWatches")
            {
                AddUpdateSW aud = new AddUpdateSW(this);
                if (aud.ShowDialog() == true)
                {
                    updateGridDataItems("SmartWatches");
                }
            }
            else if (table == "SPhonesTablets")
            {
                AddUpdateSPT aub = new AddUpdateSPT(this);
                if (aub.ShowDialog() == true)
                {
                    updateGridDataItems("SPhonesTablets");
                }
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            string table = cbDataObjects.Text;
            int index = cbDataObjects.SelectedIndex;
            StoreObject so = null;
            if (index > -1 && table == "SmartWatches")
            {
                so = (SmartWatches)gdvDataBase.SelectedItem;
            }
            else if (index > -1 && table == "SPhonesTablets")
            {
                so = (SPhonesTablets)gdvDataBase.SelectedItem;
            }
            if (table == "SmartWatches" && so != null)
            {
                AddUpdateSW aud = new AddUpdateSW(this, (SmartWatches)so);
                if (aud.ShowDialog() == true)
                {
                    updateGridDataItems("SmartWatches");
                }
            }
            else if (table == "SPhonesTablets" && so != null)
            {
                AddUpdateSPT aub = new AddUpdateSPT(this, (SPhonesTablets)so);
                if (aub.ShowDialog() == true)
                {
                    updateGridDataItems("SPhonesTablets");
                }
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            string table = cbDataObjects.Text;
            int index = cbDataObjects.SelectedIndex;
            StoreObject so = null;
            if (index > -1 && table == "SmartWatches")
            {
                so = (SmartWatches)gdvDataBase.SelectedItem;
            }
            else if (index > -1 && table == "SPhonesTablets")
            {
                so = (SPhonesTablets)gdvDataBase.SelectedItem;
            }
            DeleteDataFromTable(table, so.ID);
            if (table == "SmartWatches" && so != null)
            {
                updateGridDataItems("SmartWatches");
            }
            else if (table == "SPhonesTablets" && so != null)
            {
                updateGridDataItems("SPhonesTablets");
            }
        }


    }
}
